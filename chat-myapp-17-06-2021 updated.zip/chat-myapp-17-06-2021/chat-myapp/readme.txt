


Imoji reference :
https://www.youtube.com/watch?v=-5gwideplAY
Demo project path : C:\Users\ELCOT\Downloads\chatApp-master\chatApp-master

File sharing reference :
https://stackoverflow.com/questions/36311013/how-to-send-files-to-other-people-in-small-nodejs-chat-app
https://github.com/liamks/Delivery.js
Demo project path : C:\Users\ELCOT\Downloads\Delivery.js-master