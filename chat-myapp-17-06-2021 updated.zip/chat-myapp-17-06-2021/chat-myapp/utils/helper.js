
function testmsg(){
    return "this is the msg from helper";
}

function debuglog(msg){
    var dt = new Date();
    var time =dt.getFullYear()+':'+dt.getMonth()+':'+dt.getDate()+':'+dt.getHours()+':'+dt.getMinutes()+':'+dt.getMilliseconds();

    console.log(time+' : Info : '+msg);
}

function timestamp () {
    var time = new Date();
    return(time.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true }));
}

module.exports = {debuglog,timestamp};