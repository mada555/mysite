
var Stranger = new function(){
 'use strict';

 var socket;
 var strangerName;
 var domID = function(id){return document.getElementById(id);};
 var isBlurred = false;
 var isTyping = false;
 var alertSound = domID('alertSound');
 var chatArea = domID('chatArea');
 var imageFile = domID('imageFile');
 var chatMainDiv = domID('chatMainDiv');
 var startButton = domID('startButton');
 var peopleOnlineSpan = domID('peopleOnlineSpan');
 var sendButton = domID('sendButton');
 var strangerTyping = false;
 var disconnectType = false;
 var firstNotify = true;
 var typingTimer = null;
 var url_pattern = /https?:\/\/([-\w\.]+)+(:\d+)?(\/([\w/_\.]*(\?\S+)?)?)?/;

 alertSound.volume = 0.5;

 function setTyping(data){
    if(data.state){
        isTypingDiv.style.bottom = 80+"px";
        isTypingDiv.innerHTML = data.name+' is typing...';   
    }else{
        isTypingDiv.style.bottom = (80-isTypingDiv.offsetHeight)+"px";
    }
    strangerTyping = data.state;
 }

 function timestamp () {
    var time = new Date();
    return(time.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true }));
}

 function createConnection(){
    strangerName = $("#strangerName").val();

    //Connecting to the server
    socket = io.connect(null, {
        reconnect:false,
        'force new connection':true
    });

    //Passing user name to the server
    socket.emit('strangerName',strangerName);

    chatMainDiv.innerHTML="";
    logChat(0,"connecting to the server...");

    socket.on('connect',()=>{
        chatMainDiv.innerHTML="";
        logChat(0,"Waiting for a Stranger...");
        setTyping({state : false, name : ''});
    });

    socket.on('conn',(strangUser)=>{
        chatMainDiv.innerHTML = "";
        var userMsg = "You are now connected with "+strangUser+". Say hi!";
        logChat(0, userMsg);
        disconnectButton.disabled = false;
        disconnectButton.value = "Disconnect";
        chatArea.disabled = false;
        chatArea.value = "";
        chatArea.focus();
    });

    //Disconnecting both users and showing the message
    socket.on('disconn',(data)=>{
        var who = data.who;
        var strangerLeft = data.stranger;
        var reason = data.reason;
        chatArea.disabled = true;

        var leftNotify = strangerLeft +" Left";
        switch (who){
            case 1:
                logChat(0, "You Left");
                break;
            case 2:
                logChat(0,leftNotify);
                if(reason){
                    logChat(0,"Reason :"+reason);
                }
                break;
        }
        //clearTimeout(\);
        isTyping = false;
        setTyping({state : false, name : ''});
        disconnectType = true;
        disconnectButton.disabled = false;
        disconnectButton.value = "New";
        chatArea.disabled = true;
        chatArea.focus();
    });

    //Capturing Stranger msg from server and displaying to opponent
    socket.on('chat', (data)=>{
		
        logChat(2, {msg : data.msg, msgFrom : data.nameFrom, "msgType" : data.msgType});
        alertSound.currentTime = 0;
        if(isBlurred){
            alertSound.play();
        }
    });

    //Capturing stranger typing notification from server then displaying it to opponent stranger
    socket.on('typing', (data)=>{
        setTyping({state : data.stat, name : data.name});
    });

    //Capturing online users count from server then displaying it to all stranger
    socket.on('state',(state)=>{
        if(state.people !== undefined){
            peopleOnlineSpan.innerHTML = state.people;
        }
    });

    socket.on('disconnect',()=>{
        logChat(0, "Connection Disconnected Accediently");
        logChat(-1, "<input type=button value='Reconnect' onclick='Stranger.startChat();'>");
        peopleOnlineSpan.innerHTML = "0";
        chatArea.disabled = true;
        disconnectButton.disabled = true;
        setTyping({state : false, name : ''});
        disconnectType = false;
    });

    socket.on('error',(e)=>{
        logChat(0, "Connection Error");
        logChat(-1, "<input type=button value='Reconnect' onclick='Stranger.startChat();'>");
        peopleOnlineSpan = "0"; 
        chatArea.disabled = true;
        disconnectButton.disabled = true;
        setTyping({state : false, name : ''});
        disconnectType = false;
    });
 }
 
 this.startChat = function(){
    if(document.getElementById('checkPolicy').checked){

      /*  if(window.webkitNotifications){
            alert('webkit supported');
        }else{
            alert('webkit not supported');
        } */
        welcomeScreen.style.display = 'none';
		chatWindow.style.display = 'block';
        createConnection();
    }else{
        alert('Please accept Terms & Condition');
    }
 };

 this.newStranger = function(){
    if(socket){
        chatArea.disabled = true;
        disconnectButton.disabled = true;
        socket.emit('new');
        chatArea.value = "";
        chatArea.focus();
        chatMainDiv.innerHTML="";
        logChat(0, "Waiting for a stranger");
        setTyping({state : false, name : ''});
        disconnectType = false;
        disconnectButton.value = "Disconnect";
    }
 };

 this.doDisconnect = function(){
     if(disconnectType===true){  //clicking new 
         disconnectType = false;
         disconnectButton.value = "Disconnect";
         Stranger.newStranger();
     }else if(socket){  //Clicking disconnect 
         socket.emit("disconn");
         chatArea.disabled = true;
         chatArea.focus();
         disconnectType = true;
         disconnectButton.disabled = true;
         disconnectButton.value = "Disconnect";
         alert('second');
     }
 };

 function onReady(){
     startButton.disabled = false;
     startButton.focus();
 }

 setTimeout(onReady, 0);

 function blurred(){
     isBlurred = true;
     firstNotify = true;
 }

 function focused(){
     isBlurred = false;
     if(lastNotify) lastNotify.cancel();
	 if(notifyTimer) clearTimeout(notifyTimer);
 }

 //window.addEventListener("blur", blurred, false);
 //window.addEventListener("focus", focused, false);
 //Listening User Click disconnect
 disconnectButton.addEventListener('click',this.doDisconnect,false);

sendButton.addEventListener("click", function(e){
	console.log("Button clicked");
});


 //Will work once user hit "enter"
 chatArea.addEventListener("keypress", function(e){
	// alert("Ipog keypress working");
     var key = e.key;
     if(key ==='Enter'){
         console.log('enter key pressed :'+key);
         if(!e.shiftKey){
             var msg = chatArea.value;
             console.log('entered msg :'+msg);
             if(msg.length > 0){
                 if(typingTimer !== null){
                     clearTimeout(typingTimer);
                 }

                 if(isTyping){
                     socket.emit('typing', false); //emit not typing
                 }
                 isTyping = false;
                 socket.emit('chat', {"msg" : msg, "msgType" : "txt"});  //Passing Stranger message to server
                 console.log('msg time:'+timestamp());
				 
				 logChat(1, {"msg" : msg,"msgType" : "txt"});
                 //logChat(1, msg);	//Printing message in chat window for the current user
				 
                 chatArea.value = "";
             }
             e.preventDefault();
             e.returnValue = false;
             return false;
         }
     }
 },false);
 
 imageFile.addEventListener("change", function(e){
	 //alert("Ipog file change Captured");
	 
	 var file = imageFile.files[0];
	 console.log("Ipog file 1:",file);
	 
	 if(!file.type.match("image.*")){
		 alert('Please select image only.');
	 }else{
		 console.log("Ipog else block 2");
		 var reader = new FileReader();
		 
		 reader.readAsDataURL(file);
		/* reader.onload = function (e){
			 
			 alert("Now reader is working fine ");
			 console.log("reader.result :",reader.result);
			 
		 }; */
		 
		 reader.addEventListener("load", function () {
			 alert("Now reader is working fine 1");
			 console.log("reader.result 2:",reader.result);
			 var msg = reader.result;
			 var msgType = 'img';
			 
			// var img = `<img src='${msg}' class="img-fluid" />`;
			 socket.emit('chat', {"msg" : msg,"msgType" : msgType});
			 logChat(1, {"msg" : msg,"msgType" : msgType});
		 },false);
	 }
	 
 });

 //Passing user typing notification
 chatArea.addEventListener("keyup",function(e){
	// alert("keyup test");
    if(socket){
        if(typingTimer !== null){
            clearTimeout(typingTimer);
        }

        if(chatArea.value === "" && isTyping){
            socket.emit('typing', false);   //emit not typing
            isTyping = false;
        }else{
            if(!isTyping && chatArea.value.length > 0){
                socket.emit('typing', true);    //emit typing
                isTyping = true;
            }

            //setting typing timeout
            typingTimer = setTimeout(function(){
                if(socket && isTyping){
                   socket.emit('typing', false);     //emit not typing
                }
                isTyping = false;
            }, 100*1000);   //Stranger typing notifi will remain 1m 40sec
        }
    }
 }, false);
 
 function logChat(type,message){
    var who ="";
    var who2 ="";
    var displayMessage = "";
	var msgType = "";
    var node = document.createElement("div");
    var msgFrom = "";
    var msgTo = "";
    if(type === 2){
        msgFrom = message.msgFrom;
		msgType = message.msgType;
		displayMessage = message.msg;
        message = message.msg;
    }else if(type === 1){
		msgType = message.msgType;
		displayMessage = message.msg;
		message = message.msg;
	}

    if(type > 0){
        if(type===2){
            who = "<span class='strangerChat'>"+msgFrom+" "+timestamp()+" : </span>";
            who2 = "Stranger :";
        }else{
            who = "<span class='youChat'>"+strangerName+" "+timestamp()+" :</span>";
        }

        if(message.substr(0,4)==='/me '){
            message= message.substr(4);
            if(type===2){
                who = "<span class='strangerChat'>*** Stranger</span>";
                who2 = "*** Stranger";
            }else{
                who = "<span class='youChat'>*** You</span>"
            }
        }
        message = message.replace(/\</g,'&lt;').replace(/\>/g,'&gt;');
        var msg = message.split(" ");

        for(var i=0; i < msg.length; i+=1){
            if(url_pattern.test(msg[i]) && msg[i].indexOf("\"")===-1){
                msg[i]="<a href=\""+msg[i].replace(/\n/g,"")+"\" target=\"_blank\">"+msg[i].replace(/\n/g,"<br>")+"</a>";
            }else{
                msg[i] = msg[i].replace(/\n/g, "<br>");
            }
        }
        message = msg.join(" ");
		if(msgType==='img'){
			var img = `<img src='${displayMessage}' class="img-fluid" />`;
			var msgDisplay = `<div class="row justify-content-end">
                            <div class="col-6 col-sm-7 col-md-7">
                                <p class="sent float-right">
                                    ${img}
                                    
                                </p>
                            </div>
                            <div class="col-2 col-sm-1 col-md-1">
                                
                            </div>
                        </div>`;
			node.innerHTML = who + msgDisplay;			
		}else{
			node.innerHTML = who + message;
		}
		
		
						
       // node.innerHTML = who + message;
	  // node.innerHTML = who + msgDisplay;
    }else{
        node.innerHTML = "<span class='consoleChat'>"+message+"</span>";
    }

    chatMainDiv.appendChild(node);
    chatMainDiv.scrollTop = chatMainDiv.scrollHeight;
    chatMainDiv.scrollLeft = 0;
	
	document.getElementById('chatMainDiv').scrollTo(0, document.getElementById('chatMainDiv').scrollHeight);

    if(isBlurred && (type===0 || type===2)){
        alertSound.play();
        
    }
 }

};